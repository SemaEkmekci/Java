import java.util.ArrayList;

public class Ogrenci {

    private int ogrId;
    private String ogrAdSoyad;
    private int ogrYas;
    private static int syc = 990;
    public ArrayList<Ders> alinanDersler = new ArrayList<Ders>();

    public Ogrenci(int ogrId,String ogrAdSoyad, int ogrYas) {
        super();
        this.ogrId = ogrId;
        this.ogrAdSoyad = ogrAdSoyad;
        this.ogrYas = ogrYas;
    }

    public int getOgrId() {
        return ogrId;
    }

    public void setOgrId(int ogrId) {
        this.ogrId = ogrId;
    }

    public String getOgrAdSoyad() {
        return ogrAdSoyad;
    }

    public void setOgrAdSoyad(String ogrAdSoyad) {
        this.ogrAdSoyad = ogrAdSoyad;
    }

    public int getOgrYas() {
        return ogrYas;
    }

    public void setOgrYas(int ogrYas) {
        this.ogrYas = ogrYas;
    }

    public static void OgrenciEkle(ArrayList<Ogrenci> Ogrenciler,int ogrId, String ogrAdSoyad, int ogrYas,ArrayList<String> ders) {

        Ogrenciler.add(new Ogrenci(ogrId,ogrAdSoyad,ogrYas));
        for(int i = 0; i<ders.size();i++) {
            Ogrenciler.get(Ogrenciler.size()-1).alinanDersler.add(new Ders(ders.get(i)));
        }
    }

    public static void OgrenciAra(ArrayList<Ogrenci> Ogrenciler, String ogrAdsoyad) {
        int kontrol = 0;
        String boyut = "%5s %10s %n";
        for(int i = 0; i<Ogrenciler.size(); i++) {
            if(Ogrenciler.get(i).ogrAdSoyad.equals(ogrAdsoyad)) {
                System.out.printf(boyut,Ogrenciler.get(i).ogrId,Ogrenciler.get(i).ogrAdSoyad,Ogrenciler.get(i).ogrYas);
                kontrol = 1;
            }
        }
        if(kontrol == 0) {
            System.out.println(ogrAdsoyad + " adında bir öğrenci yok.");
        }
    }

    public static void OgrenciSil(ArrayList<Ogrenci> Ogrenciler, int ogrId) {
        for(int i = 0; i<Ogrenciler.size(); i++) {
            if(Ogrenciler.get(i).ogrId == ogrId) {
                Ogrenciler.remove(i);
                break;
            }
        }
    }

    public static void OgrenciListele(ArrayList <Ogrenci> Ogrenciler) {
        System.out.println("Tüm Öğrenciler");
        String boyut = "%5s %10s %n";
        for(int i = 0; i<Ogrenciler.size(); i++) {
            System.out.printf(boyut,Ogrenciler.get(i).ogrId,Ogrenciler.get(i).ogrAdSoyad,Ogrenciler.get(i).ogrYas);
        }
    }

    public static void OgrenciAyrintiliListe(ArrayList<Ogrenci> Ogrenciler) {
        System.out.println("Tüm Öğrenciler ve Aldıkları Dersler");
        System.out.println("-----------------------------------");
        for(int i = 0; i<Ogrenciler.size() ; i++)
        {   String boyut = "%5s %10s %n";
            System.out.printf(boyut,Ogrenciler.get(i).ogrId,Ogrenciler.get(i).ogrAdSoyad,Ogrenciler.get(i).ogrYas);
            for(int j = 0; j<Ogrenciler.get(i).alinanDersler.size(); j++) {
                boyut = "   %5s %10s %n";
                System.out.printf(boyut,Ogrenciler.get(i).alinanDersler.get(j).getDersId(),Ogrenciler.get(i).alinanDersler.get(j).getDersAd());
            }
        }
    }

    public static void ucretHesapla(ArrayList<Ogrenci> Ogrenciler, int ogrId) {
        int kontrol = 0;
        double dersHaneUcreti = 0;
        String kampanya = "Tek Ders Alan Öğrenciler İçin Kampanya Bulunmamaktadır.";
        for(int i = 0; i<Ogrenciler.size();i++) {
            if(Ogrenciler.get(i).ogrId == ogrId) {
                kontrol = 1;
                if(Ogrenciler.get(i).alinanDersler.size() == 2) {
                    dersHaneUcreti = (400+400*0.05)*4;
                    kampanya = "Kampanya 1";
                }
                else if(Ogrenciler.get(i).alinanDersler.size() == 3) {
                    dersHaneUcreti = (800+400*0.15)*4;
                    kampanya = "Kampanya 2";
                }else if(Ogrenciler.get(i).alinanDersler.size() > 3){
                    dersHaneUcreti = (400*(Ogrenciler.get(i).alinanDersler.size()*0.10)*4);
                    kampanya = "Kampanya 1";
                }
                else{
                    dersHaneUcreti=400*4;
                }
                System.out.println(Ogrenciler.get(i).ogrId+" "+ Ogrenciler.get(i).ogrAdSoyad+" "+ dersHaneUcreti+"₺ "+ kampanya);
            }
        }
        if(kontrol == 0)
            System.out.println(ogrId+" Id'sine sahip öğrenci bulunamadı.");
    }





}
