import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
//Sema Nur Ekmekci
//21100011050
//Ödev-2
public class Anasayfa {

    public static void main(String[] args)  throws IOException {
        ArrayList<Ogrenci> Ogrenciler = new ArrayList<Ogrenci>();
        ArrayList<Ders> Dersler = new ArrayList<Ders>();

        File fileOgrenci = new File("ogrenci.txt");
        Scanner reader = null;
        try {
            reader = new Scanner(fileOgrenci);
            int i=-1;
            while (reader.hasNextLine()) {
                String[] line = reader.nextLine().split("%");
                if (line[0].charAt(0) == '+') {
                    line[0] = line[0].replace("+","");
                    Ogrenciler.add(new Ogrenci(Integer.parseInt(line[0]),line[1],Integer.parseInt(line[2])));
                    i++;
                }
                else{
                    line[0] = line[0].replace("*","");
                    Ogrenciler.get(i).alinanDersler.add(new Ders(Integer.parseInt(line[0]),line[1]));
                }

            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            reader.close();
        }
        File fileDers = new File("ders.txt");
        try {
            reader = new Scanner(fileDers);
            while(reader.hasNextLine()){
                String[] line = reader.nextLine().split("%");
                Dersler.add(new Ders(line[1]));
            }

        } catch (Exception e) {
            System.out.println(e);
        }finally {
            reader.close();
        }

        while(1==1) {
            System.out.println("1-Ders Ekle\n2-Ders Listele\n3-Ders Ara\n4-Ders Sil\n5-Öğrenci Ekle\n6-Öğrenci Ara\n7-Öğrenci Sil\n8-Öğrenci Listele\n9-Öğrencileri Ayrıntılı Listele\n10-Öğrencilerin Ödeyeceği Tutarı Hesapla\n11-Çıkış");
            System.out.print("Seçiminiz: ");
            Scanner input = new Scanner(System.in);
            int secim = input.nextInt();
            String dersAdi = null;
            switch (secim) {
                case 1:
                    int dersEklemeKontrol = 1;
                    while(dersEklemeKontrol == 1){
                    System.out.print("Eklenecek Ders Adını Giriniz: ");
                    dersAdi = input.next();
                    for(int i = 0; i<Dersler.size();i++){
                        if(Dersler.get(i).getDersAd().equals(dersAdi)){
                            dersEklemeKontrol = 0;
                            break;
                        }
                    }
                    if(dersEklemeKontrol == 0){
                        System.out.println("Eklemek istediğiniz ders, ders listesinde mevcut. Tekrar ders giriniz");
                        dersEklemeKontrol = 1;
                    }else{
                        dersEklemeKontrol = 0;
                    }
                    }
                    Ders.DersEkle(Dersler,dersAdi);
                    break;
                case 2:
                    Ders.DersListele(Dersler);
                    break;
                case 3:
                    System.out.println("Aranacak Ders Adını Giriniz: ");
                    dersAdi = input.next();
                    Ders.DersAra(Dersler,dersAdi);
                    break;
                case 4:
                    System.out.print("Silinecek Ders Adını Giriniz: ");
                    dersAdi = input.next();
                    Ders.DersSil(Ogrenciler,Dersler,dersAdi);
                    break;
                case 5:
                    int ogrId = 0;
                    boolean kontrol = true;
                    while(kontrol){
                        System.out.print("Yeni Öğrenci Id: ");
                        ogrId = input.nextInt();
                        for(int j = 0; j < Ogrenciler.size(); j++) {
                            if(Ogrenciler.get(j).getOgrId() == ogrId) {
                                kontrol = false;
                                break;
                            }
                        }
                        if(!kontrol){
                            System.out.println(ogrId + " id'sine sahip bir öğrenci var. Ekleme işlemi yapılamadı. Yeni bir Id giriniz");
                            kontrol = true;
                        }else{
                            break;
                        }}
                    System.out.print("Yeni Öğrenci Ad: ");
                    String ogrAd = input.next();
                    System.out.print("Yeni Öğrenci Soyad: ");
                    String ogrSoyad = input.next();
                    String ogrAdSoyad = ogrAd + " " + ogrSoyad;
                    System.out.print("Yeni Öğrenci Yaş: ");
                    int yas = input.nextInt();
                    System.out.print("Öğrencinin Kaç Dersi Var? ");
                    int dersSayisi = input.nextInt();
                    ArrayList<String> ders = new ArrayList<String>();

                    for(int i = 0; i<dersSayisi; i++) {
                        int kontrolDers = 1;
                        while(kontrolDers == 1){
                            System.out.print((i+1)+". Dersin Adı: ");
                            dersAdi = input.next();
                        for(int j = 0; j<Dersler.size();j++){
                            if(Dersler.get(j).getDersAd().equals(dersAdi)){
                                kontrolDers = 0;
                                break;
                            }
                        }if(kontrolDers==1){
                            System.out.println("Girdiğiniz Ders Mevcut Değil. Lütfen Geçerli Bir Ders Giriniz");
                        }}
                        ders.add(dersAdi);
                    }
                    Ogrenci.OgrenciEkle(Ogrenciler,ogrId,ogrAdSoyad,yas,ders);
                    break;
                case 6:
                    System.out.print("Aranan Öğrenci Adı: ");
                    ogrAd = input.next();
                    System.out.print("Aranan Öğrenci Soyad: ");
                    ogrSoyad = input.next();
                    ogrAdSoyad = ogrAd+" "+ogrSoyad;
                    Ogrenci.OgrenciAra(Ogrenciler, ogrAdSoyad);
                    break;
                case 7:
                    System.out.print("Silinecek Öğrenci Id");
                    ogrId = input.nextInt();
                    Ogrenci.OgrenciSil(Ogrenciler,ogrId);
                    break;
                case 8:
                    Ogrenci.OgrenciListele(Ogrenciler);
                    break;
                case 9:
                    Ogrenci.OgrenciAyrintiliListe(Ogrenciler);
                    break;
                case 10:
                    System.out.print("Ücret Hesaplayacağınız Öğrenci Id'sini Giriniz: ");
                    ogrId =  input.nextInt();
                    Ogrenci.ucretHesapla(Ogrenciler, ogrId);
                    break;
                case 11:
                    File file = new File("ogrenci.txt");
                    BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                    for (int i = 0; i<Ogrenciler.size();i++){
                        writer.write("+"+Ogrenciler.get(i).getOgrId()+"%"+Ogrenciler.get(i).getOgrAdSoyad()+"%"+Ogrenciler.get(i).getOgrYas());
                        writer.newLine();
                        for(int j = 0; j<Ogrenciler.get(i).alinanDersler.size();j++){
                            writer.write("*"+Ogrenciler.get(i).alinanDersler.get(j).getDersId()+"%"+Ogrenciler.get(i).alinanDersler.get(j).getDersAd());
                            writer.newLine();
                        }
                    }
                    writer.close();
                    File file2 = new File("ders.txt");
                    BufferedWriter writer2 = new BufferedWriter(new FileWriter(file2));
                    for(int j = 0; j<Dersler.size();j++){
                        writer2.write(Dersler.get(j).getDersId()+"%"+Dersler.get(j).getDersAd());
                        writer2.newLine();
                    }
                    writer2.close();
                    return;
            }
        }
    }
}
