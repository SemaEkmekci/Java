import java.util.ArrayList;

public class Ders {
    private int dersId;
    private String dersAd;
    private static int syc=990;

    public Ders(String dersAd) {
        syc = syc+10;
        this.dersId = syc;
        this.dersAd = dersAd;
    }

    public Ders(int dersId, String dersAd) {
        this.dersId = dersId;
        this.dersAd = dersAd;
    }


    public int getDersId() {
        return dersId;
    }

    public void setDersId(int dersId) {
        this.dersId = dersId;
    }

    public String getDersAd() {
        return dersAd;
    }

    public void setDersAd(String dersAd) {
        this.dersAd = dersAd;
    }

    public static void DersEkle(ArrayList<Ders> Dersler,String dersAd){
        Dersler.add(new Ders(dersAd));
    }

    public static void DersListele(ArrayList<Ders> Dersler) {
        String boyut = "%5s %10s %n";
        System.out.printf(boyut ,"Ders Id","Ders Adı");
        System.out.printf(boyut,"-------","-------");
        for(int i = 0; i<Dersler.size(); i++) {
            System.out.printf(boyut,Dersler.get(i).dersId,Dersler.get(i).dersAd);
        }
    }

    public static void DersAra(ArrayList<Ders> Dersler, String dersAdi) {
        int kontrol = 0;
        for(int i = 0; i<Dersler.size(); i++) {
            if(Dersler.get(i).dersAd.equals(dersAdi)) {
                kontrol = 1;
                String boyut = "%5s %10s %n";
                System.out.printf(boyut,"-------","-------");
                System.out.printf(boyut ,"Ders Id","Ders Adı");
                System.out.printf(boyut,Dersler.get(i).dersId,Dersler.get(i).dersAd);
            }
        }
        if(kontrol == 0)
            System.out.println(dersAdi+" dersi yok");
    }

    public static void DersSil(ArrayList<Ogrenci> Ogrenciler,ArrayList<Ders> Dersler, String dersAdi) {
        int kontrol = 0;
        for(int i = 0; i<Ogrenciler.size(); i++) {
            for(int j=0; j<Ogrenciler.get(i).alinanDersler.size();j++) {
                if(Ogrenciler.get(i).alinanDersler.get(j).dersAd.equals(dersAdi)) {
                    kontrol = 1;
                    break;
                }
            }}
            if(kontrol == 1) {
                System.out.println("Dersi Alan Öğrenciler Var. Silme İşlemi Yapılamadı");
            }else {
                kontrol = 0;
                for(int i = 0; i<Dersler.size(); i++) {
                    if(Dersler.get(i).dersAd.equals(dersAdi)) {
                        Dersler.remove(i);
                        kontrol = 1;
                        break;
                    }
                }
                if(kontrol == 0) {
                    System.out.println(dersAdi+" dersi yok");
                }
            }


    }



}
