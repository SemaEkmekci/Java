import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Ogrenci {

    private int ogrId;
    private String ogrAdSoyad;
    private int ogrYas;
    private static int syc = 990;
    public ArrayList<Ders> alinanDersler = new ArrayList<Ders>();

    public Ogrenci(int ogrId,String ogrAdSoyad, int ogrYas) {
        super();
        this.ogrId = ogrId;
        this.ogrAdSoyad = ogrAdSoyad;
        this.ogrYas = ogrYas;
    }

    public int getOgrId() {
        return ogrId;
    }

    public void setOgrId(int ogrId) {
        this.ogrId = ogrId;
    }

    public String getOgrAdSoyad() {
        return ogrAdSoyad;
    }

    public void setOgrAdSoyad(String ogrAdSoyad) {
        this.ogrAdSoyad = ogrAdSoyad;
    }

    public int getOgrYas() {
        return ogrYas;
    }

    public void setOgrYas(int ogrYas) {
        this.ogrYas = ogrYas;
    }

    public static void OgrenciEkle(ArrayList<Ogrenci> Ogrenciler,int ogrId, String ogrAdSoyad, int ogrYas,ArrayList<String> ders) {

        Ogrenciler.add(new Ogrenci(ogrId,ogrAdSoyad,ogrYas));
        for(int i = 0; i<ders.size();i++) {
            Ogrenciler.get(Ogrenciler.size()-1).alinanDersler.add(new Ders(ders.get(i)));
        }
    }

    public static void OgrenciAra(ArrayList<Ogrenci> Ogrenciler, String ogrAdsoyad) {
        int kontrol = 0;
        String boyut = "%5s %10s %n";
        for(int i = 0; i<Ogrenciler.size(); i++) {
            if(Ogrenciler.get(i).ogrAdSoyad.equals(ogrAdsoyad)) {
                System.out.printf(boyut,Ogrenciler.get(i).ogrId,Ogrenciler.get(i).ogrAdSoyad,Ogrenciler.get(i).ogrYas);
                kontrol = 1;
            }
        }
        if(kontrol == 0) {
            System.out.println(ogrAdsoyad + " adında bir öğrenci yok.");
        }
    }

    public static void OgrenciSil(ArrayList<Ogrenci> Ogrenciler, int ogrId) {
        for(int i = 0; i<Ogrenciler.size(); i++) {
            if(Ogrenciler.get(i).ogrId == ogrId) {
                Ogrenciler.remove(i);
                break;
            }
        }
    }

    public static void OgrenciListele(ArrayList <Ogrenci> Ogrenciler) {
        System.out.println("Tüm Öğrenciler");
        String boyut = "%5s %10s %n";
        for(int i = 0; i<Ogrenciler.size(); i++) {
            System.out.printf(boyut,Ogrenciler.get(i).ogrId,Ogrenciler.get(i).ogrAdSoyad,Ogrenciler.get(i).ogrYas);
        }
    }

    public static void OgrenciAyrintiliListe(ArrayList<Ogrenci> Ogrenciler) {
        System.out.println("Tüm Öğrenciler ve Aldıkları Dersler");
        System.out.println("-----------------------------------");
        for(int i = 0; i<Ogrenciler.size() ; i++)
        {   String boyut = "%5s %10s %n";
            System.out.printf(boyut,Ogrenciler.get(i).ogrId,Ogrenciler.get(i).ogrAdSoyad,Ogrenciler.get(i).ogrYas);
            for(int j = 0; j<Ogrenciler.get(i).alinanDersler.size(); j++) {
                boyut = "   %5s %10s %n";
                System.out.printf(boyut,Ogrenciler.get(i).alinanDersler.get(j).getDersId(),Ogrenciler.get(i).alinanDersler.get(j).getDersAd());
            }
        }
    }

    public static void ucretHesapla(ArrayList<Ogrenci> Ogrenciler, int ogrId) {
        int kontrol = 0;
        double dersHaneUcreti = 0;
        String kampanya = "Tek Ders Alan Öğrenciler İçin Kampanya Bulunmamaktadır.";
        for(int i = 0; i<Ogrenciler.size();i++) {
            if(Ogrenciler.get(i).ogrId == ogrId) {
                kontrol = 1;
                if(Ogrenciler.get(i).alinanDersler.size() == 2) {
                    dersHaneUcreti = (400+400*0.05)*4;
                    kampanya = "Kampanya 1";
                }
                else if(Ogrenciler.get(i).alinanDersler.size() == 3) {
                    dersHaneUcreti = (800+400*0.15)*4;
                    kampanya = "Kampanya 2";
                }else if(Ogrenciler.get(i).alinanDersler.size() > 3){
                    dersHaneUcreti = (400*(Ogrenciler.get(i).alinanDersler.size()*0.10)*4);
                    kampanya = "Kampanya 1";
                }
                else{
                    dersHaneUcreti=400*4;
                }
                System.out.println(Ogrenciler.get(i).ogrId+" "+ Ogrenciler.get(i).ogrAdSoyad+" "+ dersHaneUcreti+"₺ "+ kampanya);
            }
        }
        if(kontrol == 0)
            System.out.println(ogrId+" Id'sine sahip öğrenci bulunamadı.");
    }





}
import java.util.ArrayList;

public class Ders {
    private int dersId;
    private String dersAd;
    private static int syc=990;

    public Ders(String dersAd) {
        syc = syc+10;
        this.dersId = syc;
        this.dersAd = dersAd;
    }

    public Ders(int dersId, String dersAd) {
        this.dersId = dersId;
        this.dersAd = dersAd;
    }


    public int getDersId() {
        return dersId;
    }

    public void setDersId(int dersId) {
        this.dersId = dersId;
    }

    public String getDersAd() {
        return dersAd;
    }

    public void setDersAd(String dersAd) {
        this.dersAd = dersAd;
    }

    public static void DersEkle(ArrayList<Ders> Dersler,String dersAd){
        Dersler.add(new Ders(dersAd));
    }

    public static void DersListele(ArrayList<Ders> Dersler) {
        String boyut = "%5s %10s %n";
        System.out.printf(boyut ,"Ders Id","Ders Adı");
        System.out.printf(boyut,"-------","-------");
        for(int i = 0; i<Dersler.size(); i++) {
            System.out.printf(boyut,Dersler.get(i).dersId,Dersler.get(i).dersAd);
        }
    }

    public static void DersAra(ArrayList<Ders> Dersler, String dersAdi) {
        int kontrol = 0;
        for(int i = 0; i<Dersler.size(); i++) {
            if(Dersler.get(i).dersAd.equals(dersAdi)) {
                kontrol = 1;
                String boyut = "%5s %10s %n";
                System.out.printf(boyut,"-------","-------");
                System.out.printf(boyut ,"Ders Id","Ders Adı");
                System.out.printf(boyut,Dersler.get(i).dersId,Dersler.get(i).dersAd);
            }
        }
        if(kontrol == 0)
            System.out.println(dersAdi+" dersi yok");
    }

    public static void DersSil(ArrayList<Ogrenci> Ogrenciler,ArrayList<Ders> Dersler, String dersAdi) {
        int kontrol = 0;
        for(int i = 0; i<Ogrenciler.size(); i++) {
            for(int j=0; j<Ogrenciler.get(i).alinanDersler.size();j++) {
                if(Ogrenciler.get(i).alinanDersler.get(j).dersAd.equals(dersAdi)) {
                    kontrol = 1;
                    break;
                }
            }}
        if(kontrol == 1) {
            System.out.println("Dersi Alan Öğrenciler Var. Silme İşlemi Yapılamadı");
        }else {
            kontrol = 0;
            for(int i = 0; i<Dersler.size(); i++) {
                if(Dersler.get(i).dersAd.equals(dersAdi)) {
                    Dersler.remove(i);
                    kontrol = 1;
                    break;
                }
            }
            if(kontrol == 0) {
                System.out.println(dersAdi+" dersi yok");
            }
        }


    }



}
import java.io.*;
        import java.util.ArrayList;
        import java.util.Scanner;
//Sema Nur Ekmekci
//21100011050
//Ödev-2
public class Anasayfa {

    public static void main(String[] args)  throws IOException {
        ArrayList<Ogrenci> Ogrenciler = new ArrayList<Ogrenci>();
        ArrayList<Ders> Dersler = new ArrayList<Ders>();

        File fileOgrenci = new File("ogrenci.txt");
        Scanner reader = null;
        try {
            reader = new Scanner(fileOgrenci);
            int i=-1;
            while (reader.hasNextLine()) {
                String[] line = reader.nextLine().split("%");
                if (line[0].charAt(0) == '+') {
                    line[0] = line[0].replace("+","");
                    Ogrenciler.add(new Ogrenci(Integer.parseInt(line[0]),line[1],Integer.parseInt(line[2])));
                    i++;
                }
                else{
                    line[0] = line[0].replace("*","");
                    Ogrenciler.get(i).alinanDersler.add(new Ders(Integer.parseInt(line[0]),line[1]));
                }

            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            reader.close();
        }
        File fileDers = new File("ders.txt");
        try {
            reader = new Scanner(fileDers);
            while(reader.hasNextLine()){
                String[] line = reader.nextLine().split("%");
                Dersler.add(new Ders(line[1]));
            }

        } catch (Exception e) {
            System.out.println(e);
        }finally {
            reader.close();
        }

        while(1==1) {
            System.out.println("1-Ders Ekle\n2-Ders Listele\n3-Ders Ara\n4-Ders Sil\n5-Öğrenci Ekle\n6-Öğrenci Ara\n7-Öğrenci Sil\n8-Öğrenci Listele\n9-Öğrencileri Ayrıntılı Listele\n10-Öğrencilerin Ödeyeceği Tutarı Hesapla\n11-Çıkış");
            System.out.print("Seçiminiz: ");
            Scanner input = new Scanner(System.in);
            int secim = input.nextInt();
            String dersAdi = null;
            switch (secim) {
                case 1:
                    int dersEklemeKontrol = 1;
                    while(dersEklemeKontrol == 1){
                        System.out.print("Eklenecek Ders Adını Giriniz: ");
                        dersAdi = input.next();
                        for(int i = 0; i<Dersler.size();i++){
                            if(Dersler.get(i).getDersAd().equals(dersAdi)){
                                dersEklemeKontrol = 0;
                                break;
                            }
                        }
                        if(dersEklemeKontrol == 0){
                            System.out.println("Eklemek istediğiniz ders, ders listesinde mevcut. Tekrar ders giriniz");
                            dersEklemeKontrol = 1;
                        }else{
                            dersEklemeKontrol = 0;
                        }
                    }
                    Ders.DersEkle(Dersler,dersAdi);
                    break;
                case 2:
                    Ders.DersListele(Dersler);
                    break;
                case 3:
                    System.out.println("Aranacak Ders Adını Giriniz: ");
                    dersAdi = input.next();
                    Ders.DersAra(Dersler,dersAdi);
                    break;
                case 4:
                    System.out.print("Silinecek Ders Adını Giriniz: ");
                    dersAdi = input.next();
                    Ders.DersSil(Ogrenciler,Dersler,dersAdi);
                    break;
                case 5:
                    int ogrId = 0;
                    boolean kontrol = true;
                    while(kontrol){
                        System.out.print("Yeni Öğrenci Id: ");
                        ogrId = input.nextInt();
                        for(int j = 0; j < Ogrenciler.size(); j++) {
                            if(Ogrenciler.get(j).getOgrId() == ogrId) {
                                kontrol = false;
                                break;
                            }
                        }
                        if(!kontrol){
                            System.out.println(ogrId + " id'sine sahip bir öğrenci var. Ekleme işlemi yapılamadı. Yeni bir Id giriniz");
                            kontrol = true;
                        }else{
                            break;
                        }}
                    System.out.print("Yeni Öğrenci Ad: ");
                    String ogrAd = input.next();
                    System.out.print("Yeni Öğrenci Soyad: ");
                    String ogrSoyad = input.next();
                    String ogrAdSoyad = ogrAd + " " + ogrSoyad;
                    System.out.print("Yeni Öğrenci Yaş: ");
                    int yas = input.nextInt();
                    System.out.print("Öğrencinin Kaç Dersi Var? ");
                    int dersSayisi = input.nextInt();
                    ArrayList<String> ders = new ArrayList<String>();

                    for(int i = 0; i<dersSayisi; i++) {
                        int kontrolDers = 1;
                        while(kontrolDers == 1){
                            System.out.print((i+1)+". Dersin Adı: ");
                            dersAdi = input.next();
                            for(int j = 0; j<Dersler.size();j++){
                                if(Dersler.get(j).getDersAd().equals(dersAdi)){
                                    kontrolDers = 0;
                                    break;
                                }
                            }if(kontrolDers==1){
                                System.out.println("Girdiğiniz Ders Mevcut Değil. Lütfen Geçerli Bir Ders Giriniz");
                            }}
                        ders.add(dersAdi);
                    }
                    Ogrenci.OgrenciEkle(Ogrenciler,ogrId,ogrAdSoyad,yas,ders);
                    break;
                case 6:
                    System.out.print("Aranan Öğrenci Adı: ");
                    ogrAd = input.next();
                    System.out.print("Aranan Öğrenci Soyad: ");
                    ogrSoyad = input.next();
                    ogrAdSoyad = ogrAd+" "+ogrSoyad;
                    Ogrenci.OgrenciAra(Ogrenciler, ogrAdSoyad);
                    break;
                case 7:
                    System.out.print("Silinecek Öğrenci Id");
                    ogrId = input.nextInt();
                    Ogrenci.OgrenciSil(Ogrenciler,ogrId);
                    break;
                case 8:
                    Ogrenci.OgrenciListele(Ogrenciler);
                    break;
                case 9:
                    Ogrenci.OgrenciAyrintiliListe(Ogrenciler);
                    break;
                case 10:
                    System.out.print("Ücret Hesaplayacağınız Öğrenci Id'sini Giriniz: ");
                    ogrId =  input.nextInt();
                    Ogrenci.ucretHesapla(Ogrenciler, ogrId);
                    break;
                case 11:
                    File file = new File("ogrenci.txt");
                    BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                    for (int i = 0; i<Ogrenciler.size();i++){
                        writer.write("+"+Ogrenciler.get(i).getOgrId()+"%"+Ogrenciler.get(i).getOgrAdSoyad()+"%"+Ogrenciler.get(i).getOgrYas());
                        writer.newLine();
                        for(int j = 0; j<Ogrenciler.get(i).alinanDersler.size();j++){
                            writer.write("*"+Ogrenciler.get(i).alinanDersler.get(j).getDersId()+"%"+Ogrenciler.get(i).alinanDersler.get(j).getDersAd());
                            writer.newLine();
                        }
                    }
                    writer.close();
                    File file2 = new File("ders.txt");
                    BufferedWriter writer2 = new BufferedWriter(new FileWriter(file2));
                    for(int j = 0; j<Dersler.size();j++){
                        writer2.write(Dersler.get(j).getDersId()+"%"+Dersler.get(j).getDersAd());
                        writer2.newLine();
                    }
                    writer2.close();
                    return;
            }
        }
    }
}
